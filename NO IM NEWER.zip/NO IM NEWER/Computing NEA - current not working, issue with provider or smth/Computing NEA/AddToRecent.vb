﻿Public Class AddToRecent
    Private Sub btnYes_Click(sender As Object, e As EventArgs) Handles btnYes.Click
        ' Define connection
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Define location of database
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"

        ' Logs the transaction into the system
        Dim sql As String = "INSERT INTO RecentGames (GameName,Price,Genre,Developer,BoughtOrSold,CustomerID) VALUES ('" & AddGame.txtTitle.Text & "', '" & AddGame.txtPrice.Text & "', '" & AddGame.txtGenre.Text & "', '" & AddGame.txtDeveloper.Text & "','" & AddGame.BoughtOrSold.Text & "', '" & AddGame.txtCustomerID.Text & "')"

        ' Represents the SQL statement to be executed against the data base
        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
        ' Staff member notified of successful logging of transaction
        MessageBox.Show("Game added to system, you will now be redirected to the main menu screen", "Appending of game successful")
        ' Hides current form
        Me.Hide()
        ' Shows staff menu
        StaffMenu.Show()

        'Open Database Connection
        sqlCom.Connection = conn
        conn.Open()
        ' Provides SQL command with the ability to read the database
        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()
    End Sub

    Private Sub BtnNo_Click(sender As Object, e As EventArgs) Handles BtnNo.Click
        ' Hides current form
        Me.Hide()
        ' Shows staff menu
        StaffMenu.Show()
    End Sub
End Class